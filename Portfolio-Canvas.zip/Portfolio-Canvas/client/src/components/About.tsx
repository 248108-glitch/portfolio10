import { motion } from "framer-motion";
import avatar from "@assets/mo7d_1764947160593.jpg";
import { Card, CardContent } from "@/components/ui/card";

export default function About() {
  return (
    <section id="about" className="py-20 md:py-32 bg-secondary/30">
      <div className="container mx-auto px-4 md:px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="flex flex-col md:flex-row items-center gap-12 md:gap-20"
        >
          {/* Image Column */}
          <div className="w-full md:w-1/3 flex justify-center">
            <div className="relative w-64 h-64 md:w-80 md:h-80">
              <div className="absolute inset-0 bg-gradient-to-tr from-blue-600 to-purple-600 rounded-2xl rotate-6 opacity-20 blur-lg" />
              <div className="relative w-full h-full rounded-2xl overflow-hidden border-4 border-background shadow-xl">
                <img
                  src={avatar}
                  alt="Mohammad Firas Shawar"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>

          {/* Content Column */}
          <div className="w-full md:w-2/3">
            <h2 className="text-3xl md:text-4xl font-bold font-display mb-6 relative inline-block">
              About Me
              <span className="absolute -bottom-2 left-0 w-1/3 h-1 bg-primary rounded-full" />
            </h2>
            
            <div className="space-y-4 text-lg text-muted-foreground">
              <p>
                Hello! I'm Mohammad Firas Shawar, a passionate Software Engineer based in Hebron. I enjoy creating things that live on the internet. My interest in web development started back when I decided to try editing custom Tumblr themes — turns out hacking together HTML & CSS is pretty fun!
              </p>
              <p>
                Fast-forward to today, and I've had the privilege of working on various projects, from small business websites to complex web applications. My main focus these days is building accessible, inclusive products and digital experiences for a variety of clients.
              </p>
              <p>
                When I'm not at the computer, I'm usually hanging out with friends, reading, or exploring new technologies.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4 mt-8">
              <Card className="bg-background border-none shadow-sm">
                <CardContent className="p-4 flex flex-col gap-1">
                  <span className="text-3xl font-bold text-primary">3+</span>
                  <span className="text-sm text-muted-foreground">Years Experience</span>
                </CardContent>
              </Card>
              <Card className="bg-background border-none shadow-sm">
                <CardContent className="p-4 flex flex-col gap-1">
                  <span className="text-3xl font-bold text-primary">20+</span>
                  <span className="text-sm text-muted-foreground">Projects Completed</span>
                </CardContent>
              </Card>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
