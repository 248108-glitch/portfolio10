import { Github, Linkedin, Twitter, Heart } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-secondary/50 border-t pt-16 pb-8">
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex flex-col md:flex-row justify-between items-center gap-8 mb-8">
          <div className="text-center md:text-left">
            <h2 className="text-2xl font-bold font-display mb-2">Mohammad Firas Shawar</h2>
            <p className="text-muted-foreground">Building digital experiences that matter.</p>
          </div>

          <div className="flex gap-4">
            <Button variant="ghost" size="icon" className="rounded-full hover:bg-background hover:text-primary transition-colors">
              <Github className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon" className="rounded-full hover:bg-background hover:text-blue-600 transition-colors">
              <Linkedin className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon" className="rounded-full hover:bg-background hover:text-sky-500 transition-colors">
              <Twitter className="h-5 w-5" />
            </Button>
          </div>
        </div>

        <div className="border-t border-border/50 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-muted-foreground">
          <p>&copy; {currentYear} Mohammad Firas Shawar. All rights reserved.</p>
          <p className="flex items-center gap-1">
            Made with <Heart className="h-3 w-3 text-red-500 fill-red-500" /> in Palestine
          </p>
        </div>
      </div>
    </footer>
  );
}
