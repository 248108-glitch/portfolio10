import { motion } from "framer-motion";
import { Progress } from "@/components/ui/progress";
import { 
  Code, 
  Database, 
  Layout, 
  Server, 
  Smartphone, 
  Terminal 
} from "lucide-react";

const skills = [
  { name: "HTML/CSS", percentage: 95, icon: Layout },
  { name: "JavaScript/TypeScript", percentage: 90, icon: Code },
  { name: "React.js", percentage: 85, icon: Smartphone },
  { name: "Node.js", percentage: 80, icon: Server },
  { name: "SQL/NoSQL", percentage: 75, icon: Database },
  { name: "Git/DevOps", percentage: 70, icon: Terminal },
];

export default function Skills() {
  return (
    <section id="skills" className="py-20 md:py-32">
      <div className="container mx-auto px-4 md:px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="mb-16 text-center"
        >
          <h2 className="text-3xl md:text-4xl font-bold font-display mb-4">Technical Skills</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Here are some of the technologies and tools I work with on a daily basis.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-10 max-w-4xl mx-auto">
          {skills.map((skill, index) => (
            <motion.div
              key={skill.name}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="space-y-2"
            >
              <div className="flex justify-between items-center mb-1">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-lg bg-primary/10 text-primary">
                    <skill.icon className="w-4 h-4" />
                  </div>
                  <span className="font-medium">{skill.name}</span>
                </div>
                <span className="text-sm text-muted-foreground">{skill.percentage}%</span>
              </div>
              <Progress value={skill.percentage} className="h-2" />
            </motion.div>
          ))}
        </div>

        {/* Additional Skills Tags */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="mt-16 text-center"
        >
          <h3 className="text-xl font-semibold mb-6">Other Technologies</h3>
          <div className="flex flex-wrap justify-center gap-3">
            {["Next.js", "Tailwind CSS", "Framer Motion", "Redux", "GraphQL", "Docker", "AWS", "Figma", "Jest"].map((tag) => (
              <span 
                key={tag} 
                className="px-4 py-2 bg-secondary text-secondary-foreground rounded-full text-sm font-medium hover:bg-primary hover:text-primary-foreground transition-colors cursor-default"
              >
                {tag}
              </span>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
